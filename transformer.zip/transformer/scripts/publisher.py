#!/usr/bin/env python

# Copyright (c) 2011, Willow Garage, Inc.
# All rights reserved.

import rospy
from std_msgs.msg import Float64
import sys, select, os
import time
import sys, select, termios, tty
import numpy as np
import sys

msg = """
Started open-loop controller publisher node.
"""

e = """
Communications Failed
"""
#
# def getKey():
#     tty.setraw(sys.stdin.fileno())
#     rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
#     if rlist:
#         key = sys.stdin.read(1)
#     else:
#         key = ''
#
#     termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
#     return key

if __name__=="__main__":

    rospy.init_node('transformer_publisher')
    pub_right = rospy.Publisher('/transformer/FR_axle_chassis_controller/command', Float64, queue_size=10) # Add your topic here between ''. Eg '/my_robot/steering_controller/command'
    pub_left = rospy.Publisher('/transformer/FL_axle_chassis_controller/command', Float64, queue_size=10)
    pub_move_left = rospy.Publisher('/transformer/BL_wheel_axle_controller/command', Float64, queue_size=10) # Add your topic for move here '' Eg '/my_robot/longitudinal_controller/command'
    pub_move_right = rospy.Publisher('/transformer/BR_wheel_axle_controller/command', Float64, queue_size=10)
    pub_move_link2 = rospy.Publisher('/transformer/link2_link1_controller/command', Float64, queue_size=10)
    pub_move_link3 = rospy.Publisher('/transformer/link3_link2_controller/command', Float64, queue_size=10)
    pub_move_link4 = rospy.Publisher('/transformer/link4_link3_controller/command', Float64, queue_size=10)
    pub_move_link5 = rospy.Publisher('/transformer/link5_link4_controller/command', Float64, queue_size=10)
    pub_move_link6 = rospy.Publisher('/transformer/link6_link5_controller/command', Float64, queue_size=10)
    pub_move_finger1 = rospy.Publisher('/transformer/finger1_link6_controller/command', Float64, queue_size=10)
    pub_move_finger2 = rospy.Publisher('/transformer/finger2_link6_controller/command', Float64, queue_size=10)
    # control_speed = float(input("Please enter a velocity between 0 and 10 :\n"))
    # control_turn = float(input("Please enter the steering angle in degrees:\n"))
    # t = float(input("Duration for which the car should move in seconds:\n"))
    control_speed = 10
    control_turn = 0
    # print(sys.argv[1])
    flag = int(sys.argv[1])
    # print(flag)
    # t = 20

    # try:
        # while(1):
        #     pub_right.publish(control_turn)
        #     pub_left.publish(control_turn)
        #     pub_move_left.publish(control_speed)
        #     pub_move_right.publish(control_speed)
        #
        #     print("\nPublishing steer angle = " + str(control_turn) + " radians\n")
        #     print("\nPublishing rear wheel angular velocity = " + str(control_turn) + " rad/s\n")
        #
        #     time.sleep(0.6)
    if flag == 1:
        angles_2 = np.linspace(0,3.14/2,20)
        angles_3 = np.linspace(0,3.14,20)
        dis = np.linspace(0,0.6,20)
        for i in range(20):
            pub_move_link3.publish(angles_3[i])
            pub_move_link2.publish(angles_2[i])
            pub_move_link4.publish(angles_3[i])
            pub_move_link6.publish(dis[i])
            time.sleep(0.1)
        pub_move_finger1.publish(1.57)
        pub_move_finger2.publish(1.57)
        # pub_move_link6.publish(1)


    if flag == 0:
        pub_move_finger1.publish(0.0)
        pub_move_finger2.publish(0.0)
        angles_2 = np.linspace(3.14 / 2, 0, 20)
        angles_3 = np.linspace(3.14, 0, 20)
        dis = np.linspace(0.6, 0, 20)
        # pub_move_link6.publish(0.1)
        for i in range(20):
            # print("hello im workin")
            pub_move_link3.publish(angles_3[i])
            pub_move_link2.publish(angles_2[i])
            pub_move_link4.publish(angles_3[i])
            pub_move_link6.publish(dis[i])
            time.sleep(0.1)
            # pub_move_link6.publish(0)
            # pub_move_link4.publish(0)
            # pub_move_link6.publish(0)


            # key = getKey()
            # if (key == '\x03'):
            #     break
    # except:
    #     print(e)

    # finally:
    #     pub_right.publish(0)
    #     pub_left.publish(0)
    #     pub_move_left.publish(0)
    #     pub_move_right.publish(0)

