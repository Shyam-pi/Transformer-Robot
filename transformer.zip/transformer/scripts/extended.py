#!/usr/bin/env python

# Copyright (c) 2011, Willow Garage, Inc.
# All rights reserved.

import rospy
from std_msgs.msg import Float64
import sys, select, os
import time
import sys, select, termios, tty

msg = """
Started open-loop controller publisher node.
"""

e = """
Communications Failed
"""
#
# def getKey():
#     tty.setraw(sys.stdin.fileno())
#     rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
#     if rlist:
#         key = sys.stdin.read(1)
#     else:
#         key = ''
#
#     termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
#     return key

if __name__=="__main__":

    rospy.init_node('transformer_publisher')
    pub_right = rospy.Publisher('/transformer/FR_axle_chassis_controller/command', Float64, queue_size=10) # Add your topic here between ''. Eg '/my_robot/steering_controller/command'
    pub_left = rospy.Publisher('/transformer/FL_axle_chassis_controller/command', Float64, queue_size=10)
    pub_move_left = rospy.Publisher('/transformer/BL_wheel_axle_controller/command', Float64, queue_size=10) # Add your topic for move here '' Eg '/my_robot/longitudinal_controller/command'
    pub_move_right = rospy.Publisher('/transformer/BR_wheel_axle_controller/command', Float64, queue_size=10)
    pub_joint1 = rospy.Publisher('/transformer/link2_link1_controller/command', Float64, queue_size=10)
    pub_joint2 = rospy.Publisher('/transformer/link3_link2_controller/command', Float64, queue_size=10)
    pub_joint3 = rospy.Publisher('/transformer/link4_link3_controller/command', Float64, queue_size=10)
    pub_joint4 = rospy.Publisher('/transformer/link5_link4_controller/command', Float64, queue_size=10)
    pub_joint5 = rospy.Publisher('/transformer/link6_link5_controller/command', Float64, queue_size=10)
    pub_finger1 = rospy.Publisher('/transformer/finger1_link6_controller/command', Float64, queue_size=10)
    pub_finger2 = rospy.Publisher('/transformer/finger2_link6_controller/command', Float64, queue_size=10)
    
    i = 0

    while(1):
    	if i == 1:
    	     pub_joint2.publish(3.14)
	if i == 2:
	     pub_joint1.publish(1.57)
	if i == 3:
	     pub_joint3.publish(3.14)
	if i == 4:
	     pub_joint4.publish(0)
	if i == 5:
	     pub_joint5.publish(1)
	if i == 6:
	     pub_finger2.publish(0)
         
        i = i+1
        time.sleep(2.0)
        
    except:
        print(e)

    finally:
        pub_right.publish(0)
        pub_left.publish(0)
        pub_move_left.publish(0)
        pub_move_right.publish(0)

