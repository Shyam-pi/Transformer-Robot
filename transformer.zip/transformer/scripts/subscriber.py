#!/usr/bin/env python
import rospy
from std_msgs.msg import Float64


def vel_callback(data):
    rospy.loginfo("Angular velocity of the rear wheels in rad/s = " + str(data.data))

def turn_callback(data):
    rospy.loginfo("Steering angle of the car in radians = " + str(data.data))


def listener():
    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('toycar_subscriber', anonymous=True)

    rospy.Subscriber("/toycar/FR_axle_chassis_controller/command", Float64, turn_callback)
    rospy.Subscriber("/toycar/BL_wheel_axle_controller/command", Float64, vel_callback)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()


if __name__ == '__main__':
    listener()